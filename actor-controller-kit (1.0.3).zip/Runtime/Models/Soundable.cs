using UnityEngine;

namespace AssemblyActorCore
{
    public class Soundable : Model
    {
        public void OnFootstep()
        {

        }

        public void OnLand()
        {

        }
    }
}